# Adult Income Analysis

## Objective

This project analyzes the Adult Income dataset to answer:

-   What percentage of people without college education earn more than
    \$50K per year?
-   Among them, what is the gender distribution?

## Project Structure

adult-income-analysis/ │ ├── data/ │ └── adult.csv │ ├── src/ │ └──
analysis.py │ ├── requirements.txt └── README.md

## How to Run

1.  Place adult.csv inside the data/ folder.
2.  Install dependencies:

pip install -r requirements.txt

3.  Run:

python src/analysis.py

## Author

José Müller\
Data Scientist \| AI & Analytics
