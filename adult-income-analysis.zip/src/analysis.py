
"""
Adult Income Analysis
Objective:
- Calculate the percentage of people without college who earn >50K
- Calculate gender distribution within that group
"""

import pandas as pd
import numpy as np


def load_and_clean_data(path: str) -> pd.DataFrame:
    df = pd.read_csv(path)

    df = df.apply(lambda x: x.str.strip() if x.dtype == "object" else x)
    df.replace("?", np.nan, inplace=True)
    df.dropna(inplace=True)

    return df


def create_no_college_feature(df: pd.DataFrame) -> pd.DataFrame:
    college_levels = [
        "Bachelors",
        "Masters",
        "Doctorate",
        "Prof-school",
        "Assoc-acdm",
        "Assoc-voc"
    ]

    df["no_college"] = ~df["education"].isin(college_levels)
    return df


def transform_target(df: pd.DataFrame) -> pd.DataFrame:
    df["income"] = df["income"].map({
        "<=50K": 0,
        ">50K": 1
    })
    return df


def analyze(df: pd.DataFrame):
    df_no_college = df[df["no_college"] == True]

    percent_high_income = df_no_college["income"].mean() * 100

    df_high_income = df_no_college[df_no_college["income"] == 1]

    gender_distribution = (
        df_high_income["sex"]
        .value_counts(normalize=True) * 100
    )

    return percent_high_income, gender_distribution


def main():
    df = load_and_clean_data("data/adult.csv")
    df = create_no_college_feature(df)
    df = transform_target(df)

    percent_high_income, gender_distribution = analyze(df)

    print("\n===== RESULTS =====\n")
    print(f"Percentage of people WITHOUT college earning >50K: {percent_high_income:.2f}%\n")

    for gender, value in gender_distribution.items():
        print(f"{gender}: {value:.2f}%")


if __name__ == "__main__":
    main()
